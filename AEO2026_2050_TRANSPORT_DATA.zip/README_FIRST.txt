AEO2026 TRANSPORT DATA — RAW EIA TABLES

Original source: https://www.eia.gov/outlooks/aeo/tables_ref.php
Published: 8 April 2026. Case: Counterfactual Baseline.

original_xlsx/: official EIA workbooks, intact and SHA-256 checked.
csv_all_sheets/: complete CSV copies of worksheet cell layouts.
2050_extracted_rows.csv: convenient UNVERIFIED 2050 index, not a corrected fleet.
download_manifest.csv: URLs, checksums, status and any failures.
run_summary.json: overall completeness flags.

Do NOT mix dollar years or vehicle stock and annual sales.
Upload the generated AEO2026_2050_TRANSPORT_DATA.zip to ChatGPT.
